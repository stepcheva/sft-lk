﻿/* SQL Manager for MySQL                              5.7.0.50823 */
/* -------------------------------------------------------------- */
/* Host     : 79.132.125.2                                        */
/* Port     : 3306                                                */
/* Database : sftlk                                               */


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES 'utf8' */;

SET FOREIGN_KEY_CHECKS=0;

CREATE DATABASE `sftlk`
    CHARACTER SET 'utf8'
    COLLATE 'utf8_unicode_ci';

USE `sftlk`;

/* Структура для таблицы `admins`:  */

CREATE TABLE `admins` (
  `id` INTEGER(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` VARCHAR(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` VARCHAR(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` VARCHAR(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` TIMESTAMP NULL DEFAULT NULL,
  `updated_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY USING BTREE (`id`),
  UNIQUE KEY `admins_email_unique` USING BTREE (`email`)
) ENGINE=InnoDB
AUTO_INCREMENT=1 ROW_FORMAT=DYNAMIC CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci'
;

/* Структура для таблицы `counterparties`:  */

CREATE TABLE `counterparties` (
  `id` INTEGER(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` TIMESTAMP NULL DEFAULT NULL,
  `updated_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY USING BTREE (`id`)
) ENGINE=InnoDB
AUTO_INCREMENT=2 ROW_FORMAT=DYNAMIC CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci'
;

/* Data for the `counterparties` table  (LIMIT 0,500) */

INSERT INTO `counterparties` (`id`, `name`, `created_at`, `updated_at`) VALUES
  (1,'АО ФКЛ - Код:7869',NULL,NULL);

/* Структура для таблицы `counters`:  */

CREATE TABLE `counters` (
  `id` INTEGER(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` TEXT COLLATE utf8mb4_unicode_ci NOT NULL,
  `requisites` TEXT COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` TIMESTAMP NULL DEFAULT NULL,
  `updated_at` TIMESTAMP NULL DEFAULT NULL,
  `counterparty_id` INTEGER(10) UNSIGNED NOT NULL,
  PRIMARY KEY USING BTREE (`id`),
  KEY `counters_counterparty_id_foreign` USING BTREE (`counterparty_id`),
  CONSTRAINT `counters_counterparty_id_foreign` FOREIGN KEY (`counterparty_id`) REFERENCES `counterparties` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB
AUTO_INCREMENT=2 ROW_FORMAT=DYNAMIC CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci'
;

/* Data for the `counters` table  (LIMIT 0,500) */

INSERT INTO `counters` (`id`, `name`, `address`, `requisites`, `created_at`, `updated_at`, `counterparty_id`) VALUES
  (1,'АО \"Фамадар Картона Лимитед\"','347927, Ростовская обл, Таганрог г, Поляковское ш, д. 16-а','ИНН: 6154069596 \r\nКПП: 6154069596\r\nОГРН: 1026102573001\r\nОКАТО: 60437000000\r\nр/с 40702810400154551565 \r\nБанк: РОСТОВСКИЙ ФИЛИАЛ АО ЮНИКРЕДИТ БАНК\r\nБИК 046027238\r\nкор счет 30101810200000000238\r\n','2018-05-24 00:00:00','2018-05-24 00:00:00',1);

/* Структура для таблицы `consigneers`:  */

CREATE TABLE `consigneers` (
  `id` INTEGER(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` VARCHAR(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `INN` VARCHAR(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `KPP` VARCHAR(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` TIMESTAMP NULL DEFAULT NULL,
  `updated_at` TIMESTAMP NULL DEFAULT NULL,
  `counter_id` INTEGER(10) UNSIGNED NOT NULL,
  PRIMARY KEY USING BTREE (`id`),
  UNIQUE KEY `consigneers_inn_unique` USING BTREE (`INN`),
  KEY `consigneers_counter_id_foreign` USING BTREE (`counter_id`),
  CONSTRAINT `consigneers_counter_id_foreign` FOREIGN KEY (`counter_id`) REFERENCES `counters` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB
AUTO_INCREMENT=5 ROW_FORMAT=DYNAMIC CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci'
;

/* Data for the `consigneers` table  (LIMIT 0,500) */

INSERT INTO `consigneers` (`id`, `name`, `address`, `INN`, `KPP`, `created_at`, `updated_at`, `counter_id`) VALUES
  (4,'АО \"Фамадар Картона Лимитед\"','347927, Ростовская обл, Таганрог г, Поляковское ш, д. 16-а','6154069596 ','6154069596','2018-05-24 00:00:00','2018-05-24 00:00:00',1);

/* Структура для таблицы `cooperations`:  */

CREATE TABLE `cooperations` (
  `id` INTEGER(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `min_volume` INTEGER(11) NOT NULL,
  `description` TEXT COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` TIMESTAMP NULL DEFAULT NULL,
  `updated_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY USING BTREE (`id`)
) ENGINE=InnoDB
AUTO_INCREMENT=2 ROW_FORMAT=DYNAMIC CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci'
;

/* Data for the `cooperations` table  (LIMIT 0,500) */

INSERT INTO `cooperations` (`id`, `min_volume`, `description`, `created_at`, `updated_at`) VALUES
  (1,0,'Товарный лимит - 220 000 000 руб с учетом НДС\r\nОтсрочка - 90 дн\r\nДиаметр рулона - не более 1330мм\r\nВес рулона - не более 2 тн\r\nДиаметр гильзы - 100мм\r\nДата окончания - 01.12.2018',NULL,NULL);

/* Структура для таблицы `applications`:  */

CREATE TABLE `applications` (
  `id` INTEGER(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `number` VARCHAR(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `period` DATE NOT NULL,
  `status` TINYINT(4) NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NULL DEFAULT NULL,
  `updated_at` TIMESTAMP NULL DEFAULT NULL,
  `cooperation_id` INTEGER(10) UNSIGNED NOT NULL,
  `consigneer_id` INTEGER(10) UNSIGNED NOT NULL,
  PRIMARY KEY USING BTREE (`id`),
  UNIQUE KEY `applications_number_unique` USING BTREE (`number`),
  KEY `applications_cooperation_id_foreign` USING BTREE (`cooperation_id`),
  KEY `applications_consigneer_id_foreign` USING BTREE (`consigneer_id`),
  CONSTRAINT `applications_consigneer_id_foreign` FOREIGN KEY (`consigneer_id`) REFERENCES `consigneers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `applications_cooperation_id_foreign` FOREIGN KEY (`cooperation_id`) REFERENCES `cooperations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB
AUTO_INCREMENT=1 ROW_FORMAT=DYNAMIC CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci'
;

/* Структура для таблицы `deliveries`:  */

CREATE TABLE `deliveries` (
  `id` INTEGER(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` INTEGER(11) NOT NULL,
  `description` TEXT COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY USING BTREE (`id`)
) ENGINE=InnoDB
AUTO_INCREMENT=4 ROW_FORMAT=DYNAMIC CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci'
;

/* Data for the `deliveries` table  (LIMIT 0,500) */

INSERT INTO `deliveries` (`id`, `name`, `price`, `description`) VALUES
  (1,'Самовывоз',0,'Самовывоз'),
  (2,'Автотранспорт',0,'Автотранспорт'),
  (3,'Ж/Д',0,'Вагон, Ж/Д');

/* Структура для таблицы `orders`:  */

CREATE TABLE `orders` (
  `id` INTEGER(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `date` DATE NOT NULL,
  `status` TINYINT(4) NOT NULL,
  `price` INTEGER(11) DEFAULT NULL,
  `created_at` TIMESTAMP NULL DEFAULT NULL,
  `updated_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY USING BTREE (`id`)
) ENGINE=InnoDB
AUTO_INCREMENT=1 ROW_FORMAT=DYNAMIC CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci'
;

/* Структура для таблицы `productranges`:  */

CREATE TABLE `productranges` (
  `id` INTEGER(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `brand` VARCHAR(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `grammage` VARCHAR(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `format` VARCHAR(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` INTEGER(11) NOT NULL,
  `created_at` TIMESTAMP NULL DEFAULT NULL,
  `updated_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY USING BTREE (`id`)
) ENGINE=InnoDB
AUTO_INCREMENT=122 ROW_FORMAT=DYNAMIC CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci'
;

/* Data for the `productranges` table  (LIMIT 0,500) */

INSERT INTO `productranges` (`id`, `brand`, `grammage`, `format`, `price`, `created_at`, `updated_at`) VALUES
  (62,'M (SFT Medium)','100','2100',33924,NULL,NULL),
  (63,'M (SFT Medium)','110','2100',33924,NULL,NULL),
  (64,'M (SFT Medium)','120','2100',33724,NULL,NULL),
  (65,'M (SFT Medium)','135','2100',33524,NULL,NULL),
  (66,'M (SFT Medium)','150','2100',33324,NULL,NULL),
  (67,'M3 (SFT Medium 3)','100','2100',26750,NULL,NULL),
  (68,'M3 (SFT Medium 3)','100','2100',26750,NULL,NULL),
  (69,'L2 (SFT Liner 2)','110','2100',34324,NULL,NULL),
  (70,'L2 (SFT Liner 2)','120','2100',34124,NULL,NULL),
  (71,'L2 (SFT Liner 2)','135','2100',33924,NULL,NULL),
  (72,'L2 (SFT Liner 2)','150','2100',33724,NULL,NULL),
  (73,'L2 (SFT Liner 2)','175','2100',33724,NULL,NULL),
  (74,'M (SFT Medium)','100','1700',33924,NULL,NULL),
  (75,'M (SFT Medium)','110','1700',33924,NULL,NULL),
  (76,'M (SFT Medium)','120','1700',33724,NULL,NULL),
  (77,'M (SFT Medium)','135','1700',33524,NULL,NULL),
  (78,'M (SFT Medium)','150','1700',33324,NULL,NULL),
  (79,'M3 (SFT Medium 3)','100','1700',26750,NULL,NULL),
  (80,'M3 (SFT Medium 3)','100','1700',26750,NULL,NULL),
  (81,'L2 (SFT Liner 2)','110','1700',34324,NULL,NULL),
  (82,'L2 (SFT Liner 2)','120','1700',34124,NULL,NULL),
  (83,'L2 (SFT Liner 2)','135','1700',33924,NULL,NULL),
  (84,'L2 (SFT Liner 2)','150','1700',33724,NULL,NULL),
  (85,'L2 (SFT Liner 2)','175','1700',33724,NULL,NULL),
  (86,'M (SFT Medium)','100','2500',33924,NULL,NULL),
  (87,'M (SFT Medium)','110','2500',33924,NULL,NULL),
  (88,'M (SFT Medium)','120','2500',33724,NULL,NULL),
  (89,'M (SFT Medium)','135','2500',33524,NULL,NULL),
  (90,'M (SFT Medium)','150','2500',33324,NULL,NULL),
  (91,'M3 (SFT Medium 3)','100','2500',26750,NULL,NULL),
  (92,'M3 (SFT Medium 3)','100','2500',26750,NULL,NULL),
  (93,'L2 (SFT Liner 2)','110','2500',34324,NULL,NULL),
  (94,'L2 (SFT Liner 2)','120','2500',34124,NULL,NULL),
  (95,'L2 (SFT Liner 2)','135','2500',33924,NULL,NULL),
  (96,'L2 (SFT Liner 2)','150','2500',33724,NULL,NULL),
  (97,'L2 (SFT Liner 2)','175','2500',33724,NULL,NULL),
  (98,'M (SFT Medium)','100','2000',33924,NULL,NULL),
  (99,'M (SFT Medium)','110','2000',33924,NULL,NULL),
  (100,'M (SFT Medium)','120','2000',33724,NULL,NULL),
  (101,'M (SFT Medium)','135','2000',33524,NULL,NULL),
  (102,'M (SFT Medium)','150','2000',33324,NULL,NULL),
  (103,'M3 (SFT Medium 3)','100','2000',26750,NULL,NULL),
  (104,'M3 (SFT Medium 3)','100','2000',26750,NULL,NULL),
  (105,'L2 (SFT Liner 2)','110','2000',34324,NULL,NULL),
  (106,'L2 (SFT Liner 2)','120','2000',34124,NULL,NULL),
  (107,'L2 (SFT Liner 2)','135','2000',33924,NULL,NULL),
  (108,'L2 (SFT Liner 2)','150','2000',33724,NULL,NULL),
  (109,'L2 (SFT Liner 2)','175','2000',33724,NULL,NULL),
  (110,'M (SFT Medium)','100','2200',33924,NULL,NULL),
  (111,'M (SFT Medium)','110','2200',33924,NULL,NULL),
  (112,'M (SFT Medium)','120','2200',33724,NULL,NULL),
  (113,'M (SFT Medium)','135','2200',33524,NULL,NULL),
  (114,'M (SFT Medium)','150','2200',33324,NULL,NULL),
  (115,'M3 (SFT Medium 3)','100','2200',26750,NULL,NULL),
  (116,'M3 (SFT Medium 3)','100','2200',26750,NULL,NULL),
  (117,'L2 (SFT Liner 2)','110','2200',34324,NULL,NULL),
  (118,'L2 (SFT Liner 2)','120','2200',34124,NULL,NULL),
  (119,'L2 (SFT Liner 2)','135','2200',33924,NULL,NULL),
  (120,'L2 (SFT Liner 2)','150','2200',33724,NULL,NULL),
  (121,'L2 (SFT Liner 2)','175','2200',33724,NULL,NULL);

/* Структура для таблицы `application_shipments`:  */

CREATE TABLE `application_shipments` (
  `id` INTEGER(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `volume` INTEGER(11) NOT NULL,
  `diameter` INTEGER(11) NOT NULL,
  `shipment` TINYINT(4) NOT NULL,
  `created_at` TIMESTAMP NULL DEFAULT NULL,
  `updated_at` TIMESTAMP NULL DEFAULT NULL,
  `order_id` INTEGER(10) UNSIGNED DEFAULT NULL,
  `application_id` INTEGER(10) UNSIGNED DEFAULT NULL,
  `productrange_id` INTEGER(10) UNSIGNED DEFAULT NULL,
  `delivery_id` INTEGER(10) UNSIGNED NOT NULL,
  PRIMARY KEY USING BTREE (`id`),
  KEY `application_shipments_order_id_foreign` USING BTREE (`order_id`),
  KEY `application_shipments_application_id_foreign` USING BTREE (`application_id`),
  KEY `application_shipments_productrange_id_foreign` USING BTREE (`productrange_id`),
  KEY `application_shipments_delivery_id_foreign` USING BTREE (`delivery_id`),
  CONSTRAINT `application_shipments_application_id_foreign` FOREIGN KEY (`application_id`) REFERENCES `applications` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `application_shipments_delivery_id_foreign` FOREIGN KEY (`delivery_id`) REFERENCES `deliveries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `application_shipments_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `application_shipments_productrange_id_foreign` FOREIGN KEY (`productrange_id`) REFERENCES `productranges` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB
AUTO_INCREMENT=1 ROW_FORMAT=DYNAMIC CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci'
;

/* Структура для таблицы `consigneer_deliveries`:  */

CREATE TABLE `consigneer_deliveries` (
  `id` INTEGER(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `consigneer_id` INTEGER(10) UNSIGNED DEFAULT NULL,
  `delivery_id` INTEGER(10) UNSIGNED DEFAULT NULL,
  PRIMARY KEY USING BTREE (`id`),
  KEY `consigneer_deliveries_consigneer_id_foreign` USING BTREE (`consigneer_id`),
  KEY `consigneer_deliveries_delivery_id_foreign` USING BTREE (`delivery_id`),
  CONSTRAINT `consigneer_deliveries_consigneer_id_foreign` FOREIGN KEY (`consigneer_id`) REFERENCES `consigneers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `consigneer_deliveries_delivery_id_foreign` FOREIGN KEY (`delivery_id`) REFERENCES `deliveries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB
AUTO_INCREMENT=4 ROW_FORMAT=DYNAMIC CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci'
;

/* Data for the `consigneer_deliveries` table  (LIMIT 0,500) */

INSERT INTO `consigneer_deliveries` (`id`, `consigneer_id`, `delivery_id`) VALUES
  (3,4,3);

/* Структура для таблицы `users`:  */

CREATE TABLE `users` (
  `id` INTEGER(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `lastName` VARCHAR(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `firstName` VARCHAR(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `middleName` VARCHAR(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` VARCHAR(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` VARCHAR(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` VARCHAR(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `passwordUntil` DATE DEFAULT NULL,
  `remember_token` VARCHAR(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` TIMESTAMP NULL DEFAULT NULL,
  `updated_at` TIMESTAMP NULL DEFAULT NULL,
  `counter_id` INTEGER(10) UNSIGNED DEFAULT NULL,
  PRIMARY KEY USING BTREE (`id`),
  UNIQUE KEY `users_email_unique` USING BTREE (`email`),
  KEY `users_counter_id_foreign` USING BTREE (`counter_id`),
  CONSTRAINT `users_counter_id_foreign` FOREIGN KEY (`counter_id`) REFERENCES `counters` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB
AUTO_INCREMENT=2 ROW_FORMAT=DYNAMIC CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci'
;

/* Data for the `users` table  (LIMIT 0,500) */

INSERT INTO `users` (`id`, `lastName`, `firstName`, `middleName`, `email`, `phone`, `password`, `passwordUntil`, `remember_token`, `created_at`, `updated_at`, `counter_id`) VALUES
  (1,'Тестовый','Оператор','Проверочно','d.shinshinov@sftgroup.ru','79163030180','1234512345','2018-07-20',NULL,NULL,NULL,NULL);

/* Структура для таблицы `files`:  */

CREATE TABLE `files` (
  `id` INTEGER(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `path` VARCHAR(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` TIMESTAMP NULL DEFAULT NULL,
  `updated_at` TIMESTAMP NULL DEFAULT NULL,
  `user_id` INTEGER(10) UNSIGNED DEFAULT NULL,
  `admin_id` INTEGER(10) UNSIGNED DEFAULT NULL,
  `order_id` INTEGER(10) UNSIGNED DEFAULT NULL,
  PRIMARY KEY USING BTREE (`id`),
  KEY `files_user_id_foreign` USING BTREE (`user_id`),
  KEY `files_admin_id_foreign` USING BTREE (`admin_id`),
  KEY `files_order_id_foreign` USING BTREE (`order_id`),
  CONSTRAINT `files_admin_id_foreign` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `files_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `files_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB
AUTO_INCREMENT=1 ROW_FORMAT=DYNAMIC CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci'
;

/* Структура для таблицы `contactqueries`:  */

CREATE TABLE `contactqueries` (
  `id` INTEGER(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `theme` VARCHAR(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `querytext` TEXT COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` TIMESTAMP NULL DEFAULT NULL,
  `updated_at` TIMESTAMP NULL DEFAULT NULL,
  `user_id` INTEGER(10) UNSIGNED NOT NULL,
  `file_id` INTEGER(10) UNSIGNED NOT NULL,
  PRIMARY KEY USING BTREE (`id`),
  KEY `contactqueries_user_id_foreign` USING BTREE (`user_id`),
  KEY `contactqueries_file_id_foreign` USING BTREE (`file_id`),
  CONSTRAINT `contactqueries_file_id_foreign` FOREIGN KEY (`file_id`) REFERENCES `files` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `contactqueries_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB
AUTO_INCREMENT=1 ROW_FORMAT=DYNAMIC CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci'
;

/* Структура для таблицы `cooperation_counters`:  */

CREATE TABLE `cooperation_counters` (
  `id` INTEGER(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `cooperation_id` INTEGER(10) UNSIGNED DEFAULT NULL,
  `counter_id` INTEGER(10) UNSIGNED DEFAULT NULL,
  PRIMARY KEY USING BTREE (`id`),
  KEY `cooperation_counters_cooperation_id_foreign` USING BTREE (`cooperation_id`),
  KEY `cooperation_counters_counter_id_foreign` USING BTREE (`counter_id`),
  CONSTRAINT `cooperation_counters_cooperation_id_foreign` FOREIGN KEY (`cooperation_id`) REFERENCES `cooperations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `cooperation_counters_counter_id_foreign` FOREIGN KEY (`counter_id`) REFERENCES `counters` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB
AUTO_INCREMENT=2 ROW_FORMAT=DYNAMIC CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci'
;

/* Data for the `cooperation_counters` table  (LIMIT 0,500) */

INSERT INTO `cooperation_counters` (`id`, `cooperation_id`, `counter_id`) VALUES
  (1,1,1);

/* Структура для таблицы `cooperation_productranges`:  */

CREATE TABLE `cooperation_productranges` (
  `id` INTEGER(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `cooperation_id` INTEGER(10) UNSIGNED DEFAULT NULL,
  `productrange_id` INTEGER(10) UNSIGNED DEFAULT NULL,
  PRIMARY KEY USING BTREE (`id`),
  KEY `cooperation_productranges_cooperation_id_foreign` USING BTREE (`cooperation_id`),
  KEY `cooperation_productranges_productrange_id_foreign` USING BTREE (`productrange_id`),
  CONSTRAINT `cooperation_productranges_cooperation_id_foreign` FOREIGN KEY (`cooperation_id`) REFERENCES `cooperations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `cooperation_productranges_productrange_id_foreign` FOREIGN KEY (`productrange_id`) REFERENCES `productranges` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB
AUTO_INCREMENT=61 ROW_FORMAT=DYNAMIC CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci'
;

/* Data for the `cooperation_productranges` table  (LIMIT 0,500) */

INSERT INTO `cooperation_productranges` (`id`, `cooperation_id`, `productrange_id`) VALUES
  (1,1,62),
  (2,1,63),
  (3,1,64),
  (4,1,65),
  (5,1,66),
  (6,1,67),
  (7,1,68),
  (8,1,69),
  (9,1,70),
  (10,1,71),
  (11,1,72),
  (12,1,73),
  (13,1,74),
  (14,1,75),
  (15,1,76),
  (16,1,77),
  (17,1,78),
  (18,1,79),
  (19,1,80),
  (20,1,81),
  (21,1,82),
  (22,1,83),
  (23,1,84),
  (24,1,85),
  (25,1,86),
  (26,1,87),
  (27,1,88),
  (28,1,89),
  (29,1,90),
  (30,1,91),
  (31,1,92),
  (32,1,93),
  (33,1,94),
  (34,1,95),
  (35,1,96),
  (36,1,97),
  (37,1,98),
  (38,1,99),
  (39,1,100),
  (40,1,101),
  (41,1,102),
  (42,1,103),
  (43,1,104),
  (44,1,105),
  (45,1,106),
  (46,1,107),
  (47,1,108),
  (48,1,109),
  (49,1,110),
  (50,1,111),
  (51,1,112),
  (52,1,113),
  (53,1,114),
  (54,1,115),
  (55,1,116),
  (56,1,117),
  (57,1,118),
  (58,1,119),
  (59,1,120),
  (60,1,121);

/* Структура для таблицы `providers`:  */

CREATE TABLE `providers` (
  `id` INTEGER(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY USING BTREE (`id`)
) ENGINE=InnoDB
AUTO_INCREMENT=2 ROW_FORMAT=DYNAMIC CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci'
;

/* Data for the `providers` table  (LIMIT 0,500) */

INSERT INTO `providers` (`id`, `name`) VALUES
  (1,'Каменская БКФ');

/* Структура для таблицы `counter_providers`:  */

CREATE TABLE `counter_providers` (
  `id` INTEGER(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `counter_id` INTEGER(10) UNSIGNED NOT NULL,
  `provider_id` INTEGER(10) UNSIGNED NOT NULL,
  PRIMARY KEY USING BTREE (`id`),
  KEY `counter_providers_counter_id_foreign` USING BTREE (`counter_id`),
  KEY `counter_providers_provider_id_foreign` USING BTREE (`provider_id`),
  CONSTRAINT `counter_providers_counter_id_foreign` FOREIGN KEY (`counter_id`) REFERENCES `counters` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `counter_providers_provider_id_foreign` FOREIGN KEY (`provider_id`) REFERENCES `providers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB
AUTO_INCREMENT=2 ROW_FORMAT=DYNAMIC CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci'
;

/* Data for the `counter_providers` table  (LIMIT 0,500) */

INSERT INTO `counter_providers` (`id`, `counter_id`, `provider_id`) VALUES
  (1,1,1);

/* Структура для таблицы `delivery_productranges`:  */

CREATE TABLE `delivery_productranges` (
  `id` INTEGER(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `delivery_id` INTEGER(10) UNSIGNED NOT NULL,
  `productrange_id` INTEGER(10) UNSIGNED NOT NULL,
  PRIMARY KEY USING BTREE (`id`),
  KEY `delivery_productranges_delivery_id_foreign` USING BTREE (`delivery_id`),
  KEY `delivery_productranges_productrange_id_foreign` USING BTREE (`productrange_id`),
  CONSTRAINT `delivery_productranges_delivery_id_foreign` FOREIGN KEY (`delivery_id`) REFERENCES `deliveries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `delivery_productranges_productrange_id_foreign` FOREIGN KEY (`productrange_id`) REFERENCES `productranges` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB
AUTO_INCREMENT=61 ROW_FORMAT=DYNAMIC CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci'
;

/* Data for the `delivery_productranges` table  (LIMIT 0,500) */

INSERT INTO `delivery_productranges` (`id`, `delivery_id`, `productrange_id`) VALUES
  (1,3,62),
  (2,3,63),
  (3,3,64),
  (4,3,65),
  (5,3,66),
  (6,3,67),
  (7,3,68),
  (8,3,69),
  (9,3,70),
  (10,3,71),
  (11,3,72),
  (12,3,73),
  (13,3,74),
  (14,3,75),
  (15,3,76),
  (16,3,77),
  (17,3,78),
  (18,3,79),
  (19,3,80),
  (20,3,81),
  (21,3,82),
  (22,3,83),
  (23,3,84),
  (24,3,85),
  (25,3,86),
  (26,3,87),
  (27,3,88),
  (28,3,89),
  (29,3,90),
  (30,3,91),
  (31,3,92),
  (32,3,93),
  (33,3,94),
  (34,3,95),
  (35,3,96),
  (36,3,97),
  (37,3,98),
  (38,3,99),
  (39,3,100),
  (40,3,101),
  (41,3,102),
  (42,3,103),
  (43,3,104),
  (44,3,105),
  (45,3,106),
  (46,3,107),
  (47,3,108),
  (48,3,109),
  (49,3,110),
  (50,3,111),
  (51,3,112),
  (52,3,113),
  (53,3,114),
  (54,3,115),
  (55,3,116),
  (56,3,117),
  (57,3,118),
  (58,3,119),
  (59,3,120),
  (60,3,121);

/* Структура для таблицы `migrations`:  */

CREATE TABLE `migrations` (
  `id` INTEGER(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` VARCHAR(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` INTEGER(11) NOT NULL,
  PRIMARY KEY USING BTREE (`id`)
) ENGINE=InnoDB
AUTO_INCREMENT=63 ROW_FORMAT=DYNAMIC CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci'
;

/* Data for the `migrations` table  (LIMIT 0,500) */

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
  (32,'2018_05_07_054948_create_users_table',1),
  (33,'2018_05_07_060423_create_admins_table',1),
  (34,'2018_05_07_060630_create_counterparties_table',1),
  (35,'2018_05_07_064529_create_counters_table',1),
  (36,'2018_05_07_064737_create_providers_table',1),
  (37,'2018_05_07_065529_create_counter_providers_table',1),
  (38,'2018_05_07_072140_create_deliveries_table',1),
  (39,'2018_05_07_072314_create_productranges_table',1),
  (40,'2018_05_07_072654_create_delivery_productranges_table',1),
  (41,'2018_05_07_073036_create_productrange_providers_table',1),
  (42,'2018_05_07_074217_create_contactqueries_table',1),
  (43,'2018_05_07_131827_create_consigneers_table',1),
  (44,'2018_05_07_132602_create_applications_table',1),
  (45,'2018_05_07_133024_create_files_table',1),
  (46,'2018_05_08_052419_create_application_shipments_table',1),
  (47,'2018_05_08_053625_create_orders_table',1),
  (48,'2018_05_08_054230_create_transportunits_table',1),
  (49,'2018_05_08_054525_create_order_transportunits_table',1),
  (50,'2018_05_08_054714_add_foreign_to_order_transportunits',1),
  (51,'2018_05_08_054850_create_cooperations_table',1),
  (52,'2018_05_08_055300_create_cooperation_productranges_table',1),
  (53,'2018_05_08_060545_add_foreign_counter_id_to_users_table',1),
  (54,'2018_05_08_062032_add_foreign_to_contactqueries',1),
  (55,'2018_05_08_062428_add_foreign_order_id_to_application_shipments',1),
  (56,'2018_05_08_063655_add_foreign_counter_id_to_consigneers',1),
  (57,'2018_05_08_070607_add_foreign_to_files',1),
  (58,'2018_05_08_070922_add_foreign_to_application_shipments',1),
  (59,'2018_05_08_081842_create_consigneer_deliveries_table',1),
  (60,'2018_05_08_083920_create_cooperation_counters_table',1),
  (61,'2018_05_08_084156_add_foreign_counters_table',1),
  (62,'2018_05_08_084509_add_foreigns_to_applications',1);

/* Структура для таблицы `transportunits`:  */

CREATE TABLE `transportunits` (
  `id` INTEGER(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `info` TEXT COLLATE utf8mb4_unicode_ci NOT NULL,
  `delivery_id` INTEGER(10) UNSIGNED NOT NULL,
  `created_at` TIMESTAMP NULL DEFAULT NULL,
  `updated_at` TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY USING BTREE (`id`),
  KEY `transportunits_delivery_id_foreign` USING BTREE (`delivery_id`),
  CONSTRAINT `transportunits_delivery_id_foreign` FOREIGN KEY (`delivery_id`) REFERENCES `deliveries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB
AUTO_INCREMENT=1 ROW_FORMAT=DYNAMIC CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci'
;

/* Структура для таблицы `order_transportunits`:  */

CREATE TABLE `order_transportunits` (
  `id` INTEGER(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `order_id` INTEGER(10) UNSIGNED DEFAULT NULL,
  `transportunit_id` INTEGER(10) UNSIGNED DEFAULT NULL,
  PRIMARY KEY USING BTREE (`id`),
  KEY `order_transportunits_order_id_foreign` USING BTREE (`order_id`),
  KEY `order_transportunits_transportunit_id_foreign` USING BTREE (`transportunit_id`),
  CONSTRAINT `order_transportunits_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `order_transportunits_transportunit_id_foreign` FOREIGN KEY (`transportunit_id`) REFERENCES `transportunits` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB
AUTO_INCREMENT=1 ROW_FORMAT=DYNAMIC CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci'
;

/* Структура для таблицы `productrange_providers`:  */

CREATE TABLE `productrange_providers` (
  `id` INTEGER(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `productrange_id` INTEGER(10) UNSIGNED NOT NULL,
  `provider_id` INTEGER(10) UNSIGNED NOT NULL,
  PRIMARY KEY USING BTREE (`id`),
  KEY `productrange_providers_productrange_id_foreign` USING BTREE (`productrange_id`),
  KEY `productrange_providers_provider_id_foreign` USING BTREE (`provider_id`),
  CONSTRAINT `productrange_providers_productrange_id_foreign` FOREIGN KEY (`productrange_id`) REFERENCES `productranges` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `productrange_providers_provider_id_foreign` FOREIGN KEY (`provider_id`) REFERENCES `providers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB
AUTO_INCREMENT=61 ROW_FORMAT=DYNAMIC CHARACTER SET 'utf8mb4' COLLATE 'utf8mb4_unicode_ci'
;

/* Data for the `productrange_providers` table  (LIMIT 0,500) */

INSERT INTO `productrange_providers` (`id`, `productrange_id`, `provider_id`) VALUES
  (1,62,1),
  (2,63,1),
  (3,64,1),
  (4,65,1),
  (5,66,1),
  (6,67,1),
  (7,68,1),
  (8,69,1),
  (9,70,1),
  (10,71,1),
  (11,72,1),
  (12,73,1),
  (13,74,1),
  (14,75,1),
  (15,76,1),
  (16,77,1),
  (17,78,1),
  (18,79,1),
  (19,80,1),
  (20,81,1),
  (21,82,1),
  (22,83,1),
  (23,84,1),
  (24,85,1),
  (25,86,1),
  (26,87,1),
  (27,88,1),
  (28,89,1),
  (29,90,1),
  (30,91,1),
  (31,92,1),
  (32,93,1),
  (33,94,1),
  (34,95,1),
  (35,96,1),
  (36,97,1),
  (37,98,1),
  (38,99,1),
  (39,100,1),
  (40,101,1),
  (41,102,1),
  (42,103,1),
  (43,104,1),
  (44,105,1),
  (45,106,1),
  (46,107,1),
  (47,108,1),
  (48,109,1),
  (49,110,1),
  (50,111,1),
  (51,112,1),
  (52,113,1),
  (53,114,1),
  (54,115,1),
  (55,116,1),
  (56,117,1),
  (57,118,1),
  (58,119,1),
  (59,120,1),
  (60,121,1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;